import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import AddEditProduct from './pages/AddEditProduct'
import Home from './pages/Home';
import  Navigation  from './components/Navigation';

function App() {  
  return (
      <BrowserRouter>
        <div className='App'>
          <Navigation />
          <Routes>
              <Route path='/' element={<Home/>} />
              <Route path='/add' element={<AddEditProduct/>} />
              <Route path='/update/:id' element={<AddEditProduct/>} />
          </Routes>
        </div>
      </BrowserRouter>
  );
}

export default App;
