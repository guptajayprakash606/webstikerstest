import React, {useEffect, useState} from 'react'
import { db } from "../firebase"
import { useNavigate } from 'react-router-dom'
import { collection, onSnapshot } from 'firebase/firestore'
import { Card } from 'react-bootstrap'
// import img from '../asset/1.jpg'
// import { list } from 'firebase/storage'

const Home = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    setLoading(true);
    const unsub = onSnapshot(collection(db, 'products'), (snapshot) => {
      let list = [];
      snapshot.docs.forEach((doc) => {
        list.push({id: doc.id, ...doc.data()})
      });
      setProducts(list);
      console.log(list);
      setLoading(false);
    }, (error) => {
      console.log(error);
    });
    return () => {
      unsub(); 
    }
  }, []);

  return (
    <div>
        <div className='container mt-3'>
            <div className='row'>
              {products.map((item) => {
                <div className='col-4' key={item.id}>
                  <Card>
                    <Card.Img variant="top" src={item.image} />
                    <Card.Body>
                        <Card.Title>{item.Name}</Card.Title>
                        <Card.Footer className='mt-3'>
                          <Card.Subtitle className='d-flex justify-content-between'>
                              <h5 className='text-start'>{item.Price}</h5>
                              <h5 className='text-end'>{item.Offer_Price}</h5>
                          </Card.Subtitle>
                        </Card.Footer>
                    </Card.Body>
                  </Card>
                </div>
              })}
                
            </div>
        </div>
    </div>
  )
}

export default Home